package com.globalsoftwaresupport;

public class App {

	public static void main(String[] args) {
		
		SimulatedAnnealing simulation = new SimulatedAnnealing();
		simulation.findOptimum();
		
	}
}
