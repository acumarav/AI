package com.udemy.bruteforce;

public class App {

	public static void main(String[] args) {
		
		BruteForce bruteForce = new BruteForce();
		
		bruteForce.bruteForceSearch();
		
	}
}
